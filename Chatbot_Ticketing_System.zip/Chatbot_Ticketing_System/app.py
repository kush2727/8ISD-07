from flask import Flask, render_template, jsonify, request, session, redirect, url_for
from datetime import datetime
import qrcode
import io
import base64

app = Flask(__name__)
app.secret_key = 'sk-6zXLmwhw-DcQXCkVTOcXN5_kKUdPhXP6ZBQMl3nwiWT3BlbkFJEPTdCVjIKWAMWVQnkCEqQvt8F0yKp96XBvopWVtnMA'  # Required for session management

# Sample museum data
museums = [
    {
        'name': 'National Museum, New Delhi',
        'image': 'https://lh3.googleusercontent.com/p/AF1QipNLylTwlySyiiV_MhkdAwHCmKP3Kg1WfsVJ40QK=s1360-w1360-h1020',
        'price': '₹50 for Indians, ₹650 for foreigners',
        'location': 'Janpath Road, New Delhi',
        'timing': '10:00 AM - 6:00 PM (Closed on Mondays)'
    },
    {
        'name': 'Salar Jung Museum, Hyderabad',
        'image': 'https://salarjungmuseum.in/images/Velied_Rebecca/1(1).jpg',
        'price': '₹40 for Indians, ₹500 for foreigners',
        'location': 'Salar Jung Road, Hyderabad',
        'timing': '10:00 AM - 5:00 PM (Closed on Fridays)'
    },
    {
        'name': 'Indian Museum, Kolkata',
        'image': 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEjWeFJmq7y-srHUG8EqckQqLKLFvWAMrakGBddw_t7onypGBNqo7x6G_hyphenhyphenI_KOWfcoCCcRO1DKMbKlbsa5oHLaax5UaH0b-RAphxPKYs6jByYAa3EVw2F4TpPGsSshWPg3qofWD6AbSixs/s800/Dec%20trip%20280.JPG',
        'price': '₹30 for Indians, ₹500 for foreigners',
        'location': 'Park Street Area, Kolkata',
        'timing': '10:00 AM - 5:00 PM (Closed on Mondays)'
    },
    {
        'name': 'Chatrapati Shivaji Maharaj Vastu Sangrahalaya, Mumbai',
        'image': 'https://preview.redd.it/chhatrapati-shivaji-maharaj-vastu-sangrahalaya-everyone-v0-fj4j6ztnftua1.jpg?width=640&crop=smart&auto=webp&s=6affd31a13ef2f174348ad0f52bcd73507d3499c',
        'price': '₹85 for Indians, ₹500 for foreigners',
        'location': 'Mahatma Gandhi Road, Fort, Mumbai',
        'timing': '10:15 AM - 6:00 PM (Open all days)'
    },
    {
        'name': 'Government Museum, Chennai',
        'image': 'https://indiano.travel/wp-content/uploads/2022/04/Beautiful-facade-at-the-Chennai-Government-Museum-Tamil-Nadu-India.jpg',
        'price': '₹20 for Indians, ₹250 for foreigners',
        'location': 'Pantheon Road, Egmore, Chennai',
        'timing': '9:30 AM - 5:00 PM (Closed on Fridays)'
    },
    {
        'name': 'Albert Hall Museum, Jaipur',
        'image': 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/18/Albert_Hall_%28_Jaipur_%29.jpg/1200px-Albert_Hall_%28_Jaipur_%29.jpg',
        'price': '₹40 for Indians, ₹300 for foreigners',
        'location': 'Ram Niwas Garden, Jaipur',
        'timing': '9:00 AM - 5:00 PM (Open all days)'
    },
    {
        'name': 'Calico Museum of Textiles, Ahmedabad',
        'image': 'https://www.gujarattourism.com/content/dam/gujrattourism/images/museums/the-calico-museum-of-textiles/gallery/Calico-Craft-Centre%20(6).jpg',
        'price': '₹30 for Indians, ₹200 for foreigners',
        'location': 'Shahibag, Ahmedabad',
        'timing': '10:00 AM - 4:00 PM (Closed on Wednesdays)'
    },
    {
        'name': 'Victoria Memorial Hall, Kolkata',
        'image': 'https://upload.wikimedia.org/wikipedia/commons/7/72/Victoria_Memorial_situated_in_Kolkata.jpg',
        'price': '₹30 for Indians, ₹500 for foreigners',
        'location': 'Queen\'s Way, Kolkata',
        'timing': '10:00 AM - 6:00 PM (Closed on Mondays)'
    },
    {
        'name': 'National Rail Museum, New Delhi',
        'image': 'https://www.nrmindia.org/assets/img/about.webp',
        'price': '₹50 for Indians, ₹650 for foreigners',
        'location': 'Chanakyapuri, New Delhi',
        'timing': '9:30 AM - 5:30 PM (Closed on Mondays)'
    },
    {
        'name': 'Maharaja Fateh Singh Museum, Vadodara',
        'image': 'https://www.gujarattourism.com/content/dam/gujrattourism/images/heritage-sites/laxmi-vilas-palace/Laxmi-Vilas-Palace-Thumbnail.jpg',
        'price': '₹25 for Indians, ₹200 for foreigners',
        'location': 'Lukshmi Vilas Palace Complex, Vadodara',
        'timing': '10:00 AM - 5:30 PM (Open all days)'
    },
    {
        'name': 'National Gallery of Modern Art, Bengaluru',
        'image': 'https://www.vagroup.com/wp-content/uploads/2019/11/6-11.jpg',
        'price': '₹20 for Indians, ₹500 for foreigners',
        'location': 'Palace Road, Bengaluru',
        'timing': '11:00 AM - 6:30 PM (Closed on Mondays)'
    },
    {
        'name': 'Dr. Bhau Daji Lad Mumbai City Museum',
        'image': 'https://www.bdlmuseum.org/assets/bdlimages/pagesbannerimages/aboutus/about-banner-large.jpg',
        'price': '₹100 for Indians, ₹400 for foreigners',
        'location': 'Byculla East, Mumbai',
        'timing': '10:00 AM - 6:00 PM (Closed on Wednesdays)'
    },
    {
        'name': 'Government Museum and Art Gallery, Chandigarh',
        'image': 'https://s7ap1.scene7.com/is/image/incredibleindia/government-museum-and-art-gallery-chandigarh-1-attr-hero?qlt=82&ts=1727353588570',
        'price': '₹10 for Indians, ₹100 for foreigners',
        'location': 'Sector 10, Chandigarh',
        'timing': '10:00 AM - 4:30 PM (Closed on Mondays)'
    },
    {
        'name': 'Napier Museum, Thiruvananthapuram',
        'image': 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/59/The_Napier_Museum_of_Thiruvananthapuram%2C_Kerala_02.jpg/2560px-The_Napier_Museum_of_Thiruvananthapuram%2C_Kerala_02.jpg',
        'price': '₹20 for Indians, ₹200 for foreigners',
        'location': 'LMS Vellayambalam Road, Thiruvananthapuram',
        'timing': '10:00 AM - 5:00 PM (Closed on Mondays)'
    },
    {
        'name': 'State Museum Lucknow',
        'image': 'https://static.toiimg.com/thumb/47673220/Things-to-do-in-Lucknow-for-culture-lovers.jpg?width=1200&height=900',
        'price': '₹10 for Indians, ₹100 for foreigners',
        'location': 'Banarasi Bagh, Lucknow',
        'timing': '10:30 AM - 4:30 PM (Closed on Mondays)'
    },
    {
        'name': 'Patna Museum',
        'image': 'https://s7ap1.scene7.com/is/image/incredibleindia/patna-museum-patna-bihar-1-musthead-hero?qlt=82&ts=1726740216293',
        'price': '₹15 for Indians, ₹150 for foreigners',
        'location': 'Buddha Marg, Patna',
        'timing': '10:00 AM - 5:00 PM (Closed on Mondays)'
    },
    {
        'name': 'Archaeological Museum, Hampi',
        'image': 'https://s7ap1.scene7.com/is/image/incredibleindia/archaeological-museum-hampi-1-attr-hero?qlt=82&ts=1726721792208',
        'price': '₹5 for Indians, ₹100 for foreigners',
        'location': 'Hampi Bazaar Road, Hampi',
        'timing': '10:00 AM - 5:00 PM (Closed on Fridays)'
    },
    {
        'name': 'Baroda Museum and Picture Gallery',
        'image': 'https://www.gujarattourism.com/content/dam/gujrattourism/images/museums/baroda-museum-and-picture-gallery/Baroda-Museum-And-Picture-Gallery-Banner.jpg',
        'price': '₹15 for Indians, ₹200 for foreigners',
        'location': 'Sayajibaug, Vadodara',
        'timing': '10:30 AM - 5:30 PM (Closed on Wednesdays)'
    },
    {
        'name': 'Madhya Pradesh Tribal Museum',
        'image': 'https://cdn.elebase.io/173fe953-8a63-4a8a-8ca3-1bacb56d78a5/8a45764f-15e0-4562-b865-766db2f38293-tribal-gallery-01-michaelturtle.jpg?w=1000&h=500&fit=crop&q=75',
        'price': '₹10 for Indians, ₹100 for foreigners',
        'location': 'Shyamla Hills, Bhopal',
        'timing': '12:00 PM - 7:00 PM (Closed on Mondays)'
    },
    {
        'name': 'Odisha State Museum',
        'image': 'https://bhubaneswartourism.in/images/places-to-visit/headers/odisha-state-museum-bhubaneswar-tourism-entry-fee-timings-holidays-reviews-header.jpg',
        'price': '₹10 for Indians, ₹100 for foreigners',
        'location': 'Lewis Road, Bhubaneswar',
        'timing': '10:00 AM - 5:00 PM (Closed on Mondays)'
    },
    {
        'name': 'Assam State Museum',
        'image': 'https://assamtourism.gov.in/images/Museum2.jpg',
        'price': '₹10 for Indians, ₹100 for foreigners',
        'location': 'GNB Road, Guwahati',
        'timing': '10:00 AM - 4:30 PM (Closed on Fridays)'
    },
    {
        'name': 'Don Bosco Museum, Shillong',
        'image': 'https://www.trawell.in/admin/images/upload/648495829Shillong_Don_Bosco_Museum_Main.jpg',
        'price': '₹50 for Indians, ₹100 for foreigners',
        'location': 'Mawlai, Shillong',
        'timing': '9:00 AM - 4:30 PM (Closed on Sundays)'
    }
]

@app.route('/')
def index():
    return render_template('index.html', museums=museums)

# @app.route('/'): This defines the home page URL (/).

# def index(): This function is called when someone visits the home page.

# render_template(...): It shows the index.html file to the user and passes the museums list to it.




@app.route('/museums')
def show_museums():
    return render_template('museums.html', museums=museums)
# This shows a separate Museums page (/museums) using the museums.html file and sends the museums data to it.

@app.route('/chatbot')
def show_chatbot():
    # This opens the Chatbot interface (/chatbot).
    if request.args.get('clear'):
        session.clear()
        return redirect(url_for('show_chatbot'))

# If the URL has ?clear=true, it clears the session (chat history) and refreshes the chatbot page.

    # Initialize chat session if not exists
    if 'chat_history' not in session:
        # If it's a new user or chat, initialize things:
        session['chat_history'] = [{
            'type': 'bot',
            'message': 'Hello! I\'m your AI assistant. To help you book museum tickets, could you please tell me your name?'
        }]
        session['booking_state'] = 'ask_name'
        session['user_data'] = {}
# The bot starts by asking for the user's name and sets the booking process to 'ask_name'.



    return render_template('chatbot.html', chat_history=session.get('chat_history', []))
# Shows the chatbot page with all messages so far.
@app.route('/process_message', methods=['POST'])
def process_message():
    # This handles messages sent by the user to the chatbot.
    try:
        message = request.form.get('message', '').strip()
    # It gets the message sent from the form.
        if not message:
            return jsonify({'error': 'Message cannot be empty'}), 400
    # If it's empty, show an error.
        chat_history = session.get('chat_history', [])
        booking_state = session.get('booking_state', 'ask_name')
        
        # Add user message to chat history
        chat_history.append({
            'type': 'user',
            'message': message
        })
        session['chat_history'] = chat_history
        # Adds the user’s message to the chat history.
        
        
        # Handle different states of the booking process
        if booking_state == 'ask_name':
            session['user_data']['name'] = message
            response = f'Nice to meet you, {message}! Are you an Indian national or a foreigner? (Please type "Indian" or "Foreigner")'
            session['booking_state'] = 'ask_nationality'
            
        # Saves the name and moves to the next question about nationality.

        elif booking_state == 'ask_nationality':
            nationality = message.lower()
            if nationality in ['indian', 'foreigner']:
                session['user_data']['nationality'] = nationality
                response = 'Please provide your email address for ticket delivery.'
                session['booking_state'] = 'ask_email'
            else:
                response = 'Please type either "Indian" or "Foreigner" to proceed.'
        # Saves nationality and asks for email next.
        elif booking_state == 'ask_email':
          if '@' in message and '.' in message:
            session['user_email'] = message
            museum_list = '\n'.join([f"Museum {i+1}: {museum['name']}" for i, museum in enumerate(museums)])
            response = f"Thank you! Here are the available museums:\n\n{museum_list}\n\nPlease select a museum by entering its number (1-{len(museums)})."
            session['booking_state'] = 'select_museum'
          else:
            response = 'Please provide a valid email address.'
        # Checks if email is valid.
        
        elif booking_state == 'select_museum':
            try:
                museum_index = int(message) - 1
        # Converts the selected number into the actual museum.
                if 0 <= museum_index < len(museums):
                    selected_museum = museums[museum_index]
                    session['selected_museum'] = selected_museum
                    response = f"Here are the details for {selected_museum['name']}:\n\nLocation: {selected_museum['location']}\nTiming: {selected_museum['timing']}\nPrice: {selected_museum['price']}\n\nHow many tickets would you like to book? (Maximum: 10)"
                    session['booking_state'] = 'select_quantity'
                    # Shows details and asks how many tickets the user wants.
                else:
                    response = f'Please enter a number between 1 and {len(museums)}.'
                    
            except ValueError:
                response = 'Please enter a valid number.'
        
        elif booking_state == 'select_quantity':
            try:
                quantity = int(message)
                if 1 <= quantity <= 10:
                    # Checks if ticket number is valid.
                    session['ticket_quantity'] = quantity
                    museum = session['selected_museum']
                    # Extract price based on nationality
                    nationality = session['user_data'].get('nationality', 'indian')
          
                    # Calculates price based on nationality.
                    price_parts = museum['price'].split('₹')
                    if nationality == 'foreigner':
                        price = int(price_parts[2].split(' ')[0]) * quantity
                    else:
                        price = int(price_parts[1].split(' ')[0]) * quantity
                    session['total_price'] = price
                    response = f'Total price: ₹{price}\nPlease select a payment method:\n1. Credit Card\n2. Debit Card\n3. UPI\n4. Wallets'
                    session['booking_state'] = 'select_payment'
                    # Shows total price and moves to payment step.
                else:
                    response = 'Please enter a number between 1 and 10.'
            except ValueError:
                response = 'Please enter a valid number.'
        
        elif booking_state == 'select_payment':
            try:
                payment_method = int(message)
                # Checks if the selected payment method is valid.
                if 1 <= payment_method <= 4:
                    payment_methods = {
                        1: 'credit_card',
                        2: 'debit_card',
                        3: 'upi',
                        4: 'wallet'
                    }
                    selected_method = payment_methods[payment_method]
                    total_price = session.get('total_price', 0)
                    return jsonify({
                        'redirect_to_payment': True,
                        'payment_method': selected_method,
                        'amount': f'₹{total_price}'
                    })
                    # Returns JSON to redirect to the payment gateway.
                else:
                    response = 'Please select a valid payment method (1-4).'
            except ValueError:
                response = 'Please enter a valid number for the payment method.'
        
        elif booking_state == 'ask_more_tickets':
            if message.lower() == 'yes':
                # Clear all session data
                session.clear()
                # Initialize new chat session
                session['chat_history'] = [{
                    'type': 'bot',
                    'message': 'Hello! I\'m your AI assistant. To help you book museum tickets, could you please tell me your name?'
                }]
                session['booking_state'] = 'ask_name'
                session['user_data'] = {}
                rendered_html = render_template('chatbot_messages.html', chat_history=session['chat_history'])
                return jsonify({'html': rendered_html})
            elif message.lower() == 'no':
                # Clear session and redirect to index
                session.clear()
                return jsonify({
                    'redirect': True,
                    'url': url_for('index', _external=True)
                })
            else:
                response = 'Please type "yes" to book more tickets or "no" to return to homepage.'
                # After a booking is done, it asks if the user wants to book more tickets.


                chat_history.append({
                    'type': 'bot',
                    'message': response
                })
                session['chat_history'] = chat_history
# Stores the bot's reply in a list called chat_history.

# Keeps that list saved in the browser session so it remembers the conversation.
                rendered_html = render_template('chatbot_messages.html', chat_history=chat_history)
                return jsonify({'html': rendered_html})
        
        # Add bot response to chat history
        chat_history.append({
            'type': 'bot',
            'message': response
        })
        
        session['chat_history'] = chat_history
        rendered_html = render_template('chatbot_messages.html', chat_history=chat_history)
        return jsonify({'html': rendered_html})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/book_museum/<museum_name>', methods=['GET'])
def book_museum(museum_name):
    session.clear()
    chat_history = [{
        'type': 'bot',
        'message': f'I can help you book tickets for {museum_name}. How many tickets would you like to book?'
    }]
    session['chat_history'] = chat_history
    session['booking_state'] = 'select_quantity'
    session['selected_museum'] = next((m for m in museums if m['name'] == museum_name), None)
    return render_template('chatbot.html', chat_history=chat_history)

@app.route('/payment')
def payment():
    payment_method = request.args.get('method')
    amount = request.args.get('amount')
    
    if not payment_method or not amount:
        return redirect(url_for('show_chatbot'))
    
    session['payment_method'] = payment_method
    session['total_price'] = amount.replace('₹', '')
    
    return render_template('payment.html', 
                          payment_method=payment_method,
                          amount=amount)

@app.route('/process_payment', methods=['POST'])
def process_payment():
    if 'payment_method' not in session or 'selected_museum' not in session or 'ticket_quantity' not in session:
        return jsonify({'error': 'Invalid session. Please try booking again.'}), 400

    payment_method = request.form.get('payment_method')
    if not payment_method:
        return jsonify({'error': 'Payment method is required'}), 400
        
    # Additional validation for wallet payments
    if payment_method == 'wallet':
        wallet_provider = request.form.get('wallet_provider')
        wallet_number = request.form.get('wallet_number')
        if not wallet_provider or not wallet_number:
            return jsonify({'error': 'Wallet provider and mobile number are required'}), 400
        if not wallet_number.isdigit() or len(wallet_number) != 10:
            return jsonify({'error': 'Invalid mobile number'}), 400

    # Ensure chat_history exists and is a list
    if 'chat_history' not in session or not isinstance(session['chat_history'], list):
        session['chat_history'] = []

    try:
        # Generate ticket
        ticket_number = f"TKT{datetime.now().strftime('%Y%m%d%H%M%S')}"
        museum = session['selected_museum']
        quantity = session['ticket_quantity']
        
        # Create QR code
        qr = qrcode.QRCode(version=1, box_size=10, border=5)
        qr.add_data(f"Ticket: {ticket_number}\nMuseum: {museum['name']}\nQuantity: {quantity}")
        qr.make(fit=True)
        qr_img = qr.make_image(fill_color="black", back_color="white")
        
        # Convert QR code to base64 string
        buffered = io.BytesIO()
        qr_img.save(buffered, format="PNG")
        qr_code = base64.b64encode(buffered.getvalue()).decode()
        
        # Add ticket confirmation to chat history
        ticket_confirmation = f"""
        <div class='ticket-confirmation'>
            <h4>🎫 Booking Confirmed!</h4>
            <p><strong>Ticket Number:</strong> {ticket_number}</p>
            <p><strong>Museum:</strong> {museum['name']}</p>
            <p><strong>Quantity:</strong> {quantity}</p>
            <p><strong>Location:</strong> {museum['location']}</p>
            <p><strong>Timing:</strong> {museum['timing']}</p>
            <p><strong>Payment Method:</strong> {payment_method.replace('_', ' ').title()}</p>
            <div class='qr-code'>
                <img src='data:image/png;base64,{qr_code}' alt='QR Code'>
            </div>
        </div>
        """
        
        # Store ticket in session
        if 'tickets' not in session:
            session['tickets'] = []
        session['tickets'].append({
            'ticket_number': ticket_number,
            'museum': museum['name'],
            'quantity': quantity,
            'payment_method': payment_method
        })
        
        # Update chat history with ticket confirmation
        session['chat_history'].append({
            'type': 'bot',
            'message': ticket_confirmation,
            'time': datetime.now().strftime('%I:%M %p')
        })
        
        # Add email confirmation message
        session['chat_history'].append({
            'type': 'bot',
            'message': f'✉️ Your tickets have been successfully sent to {session["user_email"]}',
            'time': datetime.now().strftime('%I:%M %p')
        })
        
        # Add prompt for booking more tickets
        session['chat_history'].append({
            'type': 'bot',
            'message': 'Would you like to book more tickets? Type "yes" or "no"',
            'time': datetime.now().strftime('%I:%M %p')
        })
        session['booking_state'] = 'ask_more_tickets'
        
        return jsonify({'success': True})

    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/payment_success')
def payment_success():
    # Process the payment and generate ticket
    return redirect(url_for('process_payment'), code=307)  # Use 307 to preserve POST method

if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8000, debug=True)